==========
biolxyutil
==========

A command-line toolkit and Python library for detecting copy number variants
and alterations genome-wide from targeted DNA sequencing.

Read the full documentation at: https://github.com/biolxy/mypy-template


Installation
============

biolxyutil runs on Python 2 and Python 3. Your operating system might already provide Python
2.7, which you can check on the command line::

    python --version

If your operating system already includes Python 2.6, I suggest either using
``conda`` (see below) or installing Python 2.7 alongside the existing Python 2.6
instead of attempting to upgrade it in-place. Your package manager might provide
both versions of Python.

To run the recommended segmentation algorithms CBS and Fused Lasso, you will
need to also install the R dependencies (see below).


From a Python package repository
--------------------------------

Reasonably up-to-date biolxyutil packages are available on `PyPI
<https://pypi.python.org/pypi/biolxyutil>`_ and can be installed using `pip
<https://pip.pypa.io/en/latest/installing.html>`_ (usually works on Linux if the
system dependencies listed below are installed)::

    pip install biolxyutil


From source
-----------

The script ``biolxyutil.py`` requires no installation and can be used in-place. Just
install the dependencies.

To install the main program, supporting scripts and ``cnvlib`` Python library,
use ``setup.py`` as usual::

    python setup.py build
    python setup.py install


Python dependencies
-------------------

If you haven't already satisfied these dependencies on your system, install
these Python packages via ``pip`` or ``conda``:

- `Biopython <http://biopython.org/wiki/Main_Page>`_






